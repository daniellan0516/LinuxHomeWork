package in.daniel.hello;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class ControllerTest {
  @GetMapping("/")
  public String test() {
	
	ReqBody rb = new ReqBody();
	rb.setCurrency("JPY");
	rb.setMsgCode("CQRY");
	rb.setTxnDate("20220510");
	rb.setTxnSeq("1111111111");
	
	HttpHeaders headers = new HttpHeaders();
	headers.add("Content-Type", "application/json");
	HttpEntity<String> resp = new HttpEntity<>(headers);
	RestTemplate restTemplate = new RestTemplate(getClientHttpRequestFactory());
	String response = restTemplate.postForObject("http://192.168.220.137:49200/o360api/op/status/channel", resp, String.class);
    return response;
  }
  
  private SimpleClientHttpRequestFactory getClientHttpRequestFactory() {
	    SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
	    clientHttpRequestFactory.setConnectTimeout(1000);// 毫秒
	    return clientHttpRequestFactory;
  }
  
}
